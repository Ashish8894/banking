<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Transaction History')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900">
                    <div class="flex justify-between items-center mb-6">
                        <?php if($user->usertype === 'User'): ?>
                            <h3 class="text-lg font-semibold">Your Transactions</h3>
                            <a href="<?php echo e(route('transactions.create')); ?>" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">
                                New Transaction
                            </a>
                        <?php endif; ?>
                        <?php if($user->usertype === 'Admin'): ?>
                            <h3 class="text-lg font-semibold">All Transactions</h3>
                        <?php endif; ?>
                    </div>

                    <?php if(session('success')): ?>
                        <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative mb-4" role="alert">
                            <span class="block sm:inline"><?php echo e(session('success')); ?></span>
                        </div>
                    <?php endif; ?>

                    <?php if($transactions->count() > 0): ?>
                        <div class="overflow-x-auto">
                            <table class="min-w-full bg-white">
                                <thead>
                                    <tr>
                                        <th class="py-2 px-4 border-b border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">ID</th>
                                        <th class="py-2 px-4 border-b border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Date</th>
                                        <th class="py-2 px-4 border-b border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Type</th>
                                        <th class="py-2 px-4 border-b border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Amount</th>
                                        <th class="py-2 px-4 border-b border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Description</th>
                                        <th class="py-2 px-4 border-b border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Status</th>
                                        <th class="py-2 px-4 border-b border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td class="py-2 px-4 border-b border-gray-200"><?php echo e($transaction->id); ?></td>
                                            <td class="py-2 px-4 border-b border-gray-200"><?php echo e($transaction->created_at->format('M d, Y H:i')); ?></td>
                                            <td class="py-2 px-4 border-b border-gray-200">
                                                <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full 
                                                    <?php echo e($transaction->type === 'deposit' ? 'bg-green-100 text-green-800' : ''); ?>

                                                    <?php echo e($transaction->type === 'withdrawal' ? 'bg-red-100 text-red-800' : ''); ?>

                                                    <?php echo e($transaction->type === 'transfer' ? 'bg-blue-100 text-blue-800' : ''); ?>">
                                                    <?php echo e(ucfirst($transaction->type)); ?>

                                                </span>
                                            </td>
                                            <td class="py-2 px-4 border-b border-gray-200">
                                                <span class="<?php echo e($transaction->type === 'deposit' ? 'text-green-600' : ''); ?>

                                                    <?php echo e($transaction->type === 'withdrawal' || $transaction->type === 'transfer' ? 'text-red-600' : ''); ?>">
                                                    $<?php echo e(number_format($transaction->amount, 2)); ?>

                                                </span>
                                            </td>
                                            <td class="py-2 px-4 border-b border-gray-200">
                                                <?php echo e($transaction->description ?? 'N/A'); ?>

                                                <?php if($transaction->type === 'transfer'): ?>
                                                    <span class="text-sm text-gray-500">
                                                        (To: <?php echo e($transaction->recipient->name ?? 'Unknown'); ?>)
                                                    </span>
                                                <?php endif; ?>
                                            </td>
                                            <td class="py-2 px-4 border-b border-gray-200">
                                                <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full 
                                                    <?php echo e($transaction->status === 'completed' ? 'bg-green-100 text-green-800' : ''); ?>

                                                    <?php echo e($transaction->status === 'pending' ? 'bg-yellow-100 text-yellow-800' : ''); ?>

                                                    <?php echo e($transaction->status === 'failed' ? 'bg-red-100 text-red-800' : ''); ?>">
                                                    <?php echo e(ucfirst($transaction->status)); ?>

                                                </span>
                                            </td>
                                            <td class="py-2 px-4 border-b border-gray-200">
                                                <a href="<?php echo e(route('transactions.show', $transaction)); ?>" class="text-blue-600 hover:text-blue-900">View</a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                        
                        <div class="mt-4">
                            <?php echo e($transactions->links()); ?>

                        </div>
                    <?php else: ?>
                        <p class="text-gray-500">No transactions found.</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\Banking_task\resources\views/transactions/index.blade.php ENDPATH**/ ?>