<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            {{ __('Transaction Details') }}
        </h2>
    </x-slot>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900">
                    <div class="mb-6">
                    @if($user->usertype === 'User')
                        <a href="{{ route('transactions.index') }}" class="text-blue-600 hover:text-blue-800">
                            &larr; Back to Transactions
                        </a>
                        @endif
                        @if($user->usertype === 'Admin')
                        <a href="{{ route('dashboard') }}" class="text-blue-600 hover:text-blue-800">
                            &larr; Back to Transactions
                        </a>
                        @endif
                    </div>
                    
                    <div class="bg-gray-100 p-6 rounded-lg shadow-md">
                        <h3 class="text-lg font-semibold mb-4">Transaction #{{ $transaction->id }}</h3>
                        
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                                <p class="text-sm text-gray-600">Date</p>
                                <p class="font-medium">{{ $transaction->created_at->format('F d, Y h:i A') }}</p>
                            </div>
                            
                            <div>
                                <p class="text-sm text-gray-600">Type</p>
                                <p class="font-medium">
                                    <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full 
                                        {{ $transaction->type === 'deposit' ? 'bg-green-100 text-green-800' : '' }}
                                        {{ $transaction->type === 'withdrawal' ? 'bg-red-100 text-red-800' : '' }}
                                        {{ $transaction->type === 'transfer' ? 'bg-blue-100 text-blue-800' : '' }}">
                                        {{ ucfirst($transaction->type) }}
                                    </span>
                                </p>
                            </div>
                            
                            <div>
                                <p class="text-sm text-gray-600">Amount</p>
                                <p class="font-medium {{ $transaction->type === 'deposit' ? 'text-green-600' : '' }}
                                    {{ $transaction->type === 'withdrawal' || $transaction->type === 'transfer' ? 'text-red-600' : '' }}">
                                    ${{ number_format($transaction->amount, 2) }}
                                </p>
                            </div>
                            
                            <div>
                                <p class="text-sm text-gray-600">Status</p>
                                <p class="font-medium">
                                    <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full 
                                        {{ $transaction->status === 'completed' ? 'bg-green-100 text-green-800' : '' }}
                                        {{ $transaction->status === 'pending' ? 'bg-yellow-100 text-yellow-800' : '' }}
                                        {{ $transaction->status === 'failed' ? 'bg-red-100 text-red-800' : '' }}">
                                        {{ ucfirst($transaction->status) }}
                                    </span>
                                </p>
                            </div>
                            
                            @if($transaction->type === 'transfer')
                                <div>
                                    <p class="text-sm text-gray-600">Recipient</p>
                                    <p class="font-medium">{{ $transaction->recipient->name ?? 'Unknown' }}</p>
                                    <p class="text-xs text-gray-500">Account: {{ $transaction->recipient->account_number ?? 'N/A' }}</p>
                                </div>
                            @endif
                            
                            <div class="md:col-span-2">
                                <p class="text-sm text-gray-600">Description</p>
                                <p class="font-medium">{{ $transaction->description ?? 'No description provided' }}</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</x-app-layout>