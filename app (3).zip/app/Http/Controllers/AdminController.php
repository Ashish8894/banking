<?php
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class AdminController extends Controller
{
    public function createAccounts()
    {
        return view('admin.create_accounts');
    }

    public function storeAccounts(Request $request)
    {
        $accounts = $request->input('accounts');

        foreach ($accounts as $account) {
            User::create([
                'first_name' => $account['first_name'],
                'last_name' => $account['last_name'],
                'dob' => $account['dob'],
                'address' => $account['address'],
                'account_number' => $this->generateAccountNumber(),
                'balance' => 10000,
                'usertype' => 'user',
                'password' => Hash::make('defaultPassword'), // or customize as needed
            ]);
        }

        return redirect()->route('admin.createAccounts')->with('success', 'Accounts created successfully!');
    }

    private function generateAccountNumber()
    {
        return 'ACC' . str_pad(mt_rand(1, 99999999), 8, '0', STR_PAD_LEFT);
    }
}
