<?php

namespace App\Http\Controllers;

use App\Models\Transaction;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Log;

class TransactionController extends Controller
{
    /**
     * Display a listing of the transactions.
     */
    public function index()
    {
        $user = Auth::user();
        $transactions = Auth::user()->transactions()->with('recipient')->latest()->paginate(10);
        return view('transactions.index', compact('transactions','user'));
    }

    public function create_account()
    {
        $user = Auth::user();
        // $transactions = Auth::user()->transactions()->with('recipient')->latest()->paginate(10);
        return view('admin.create_accounts', compact('user'));
    }

    /**
     * Show the form for creating a new transaction.
     */
    public function create()
    {
        $users = User::where('id', '!=', Auth::id())
              ->where('usertype', '!=', 'admin')
              ->get();
        return view('transactions.create', compact('users'));
    }

    /**
     * Store a newly created transaction in storage.
     */
    public function store(Request $request)
    {
        Log::info('Store method called', $request->all());

        // Check if the user is authenticated
        if (!Auth::check()) {
            Log::error('User not authenticated');
            return redirect()->route('login');
        }

        $request->validate([
            'type' => 'required|in:deposit,withdrawal,transfer',
            'amount' => 'required|numeric|min:0.01',
            'description' => 'nullable|string|max:255',
            'recipient_id' => 'nullable|required_if:type,transfer|exists:users,id',
        ]);

        $user = Auth::user();
        $amount = $request->amount;
        $type = $request->type;
        $recipientId = $request->recipient_id;

        // Check balance for withdrawals and transfers
        if (in_array($type, ['withdrawal', 'transfer']) && $user->balance < $amount) {
            Log::error('Insufficient balance', ['balance' => $user->balance, 'amount' => $amount]);
            return back()->withErrors(['amount' => 'Insufficient balance for this transaction.']);
        }

        try {
            DB::beginTransaction();

            // Create the transaction
            $transaction = new Transaction([
                'user_id' => $user->id,
                'amount' => $amount,
                'type' => $type,
                'description' => $request->description,
                'status' => 'completed',
            ]);

            // Balance updates
            if ($type === 'deposit') {
                $user->balance += $amount;
            } elseif ($type === 'withdrawal') {
                $user->balance -= $amount;
            } elseif ($type === 'transfer') {
                $recipient = User::find($recipientId);
                if (!$recipient) {
                    throw new \Exception('Recipient not found.');
                }

                $transaction->recipient_id = $recipient->id;
                $user->balance -= $amount;
                $recipient->balance += $amount;

                $recipient->save();
            }

            $user->save();
            $transaction->save();

            DB::commit();

            Log::info('Transaction successful', ['transaction_id' => $transaction->id]);

            return redirect()->route('transactions.index')
                ->with('success', 'Transaction completed successfully.');
        } catch (\Exception $e) {
            DB::rollBack();
            Log::error('Transaction failed', ['error' => $e->getMessage()]);
            return back()->withErrors(['error' => 'Transaction failed: ' . $e->getMessage()]);
        }
    }

    public function account_save(Request $request){
        $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|email|unique:users,email',
            'password' => 'required|string|min:8',
        ]);

        // Get the last account number and increment it
        $lastAccount = User::latest('account_number')->first();
        $newAccountNumber = $lastAccount ? $lastAccount->account_number + 1 : 1000000000;

        // Create the user
        User::create([
            'name' => $request->name,
            'email' => $request->email,
            'password' => Hash::make($request->password),
            'account_number' => $newAccountNumber,
            'usertype' => 'User',
        ]);

        return redirect()->back()->with('success', 'Account created successfully!');
    }
    /**
     * Display the specified transaction.
     */
    public function show(Transaction $transaction)
    {
        $user = Auth::user();
        if($user && $user->usertype === 'User'){
            if ($transaction->user_id !== Auth::id()) {
                abort(403, 'Unauthorized action.');
            }
        }

        return view('transactions.show', compact('transaction','user'));
    }
}
