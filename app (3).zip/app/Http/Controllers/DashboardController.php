<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\Transaction;
class DashboardController extends Controller
{
    /**
     * Display the user's dashboard.
     */
    public function index()
    {
        $user = Auth::user();
        // $recentTransactions = $user->transactions()->with('recipient')->latest()->take(5)->get();

        
        
        
        if ($user && $user->usertype === 'Admin') {
            $transactions = Transaction::with('recipient')->latest()->paginate(10);

            return view('transactions.index', compact('user', 'transactions'));
            
        } elseif ($user && $user->usertype === 'User') {
            $transactions = Auth::user()->transactions()->with('recipient')->latest()->paginate(10);
            return view('transactions.index', compact('transactions','user'));
        }

        // return view('dashboard', compact('user', 'recentTransactions'));
    }
}